#![cfg(feature = "read")]

mod coff;
