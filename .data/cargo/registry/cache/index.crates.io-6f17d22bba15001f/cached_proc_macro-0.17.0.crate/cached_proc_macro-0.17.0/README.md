See https://crates.io/crates/cached
